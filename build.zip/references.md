## Is element in viewport
https://stackoverflow.com/questions/123999/how-can-i-tell-if-a-dom-element-is-visible-in-the-current-viewport#answer-7557433


## Linking to text JS, probably need to import this.
https://stackoverflow.com/questions/71806679/how-to-copy-link-to-highlight-using-chrome-api#answer-73425285

https://stackoverflow.com/questions/985272/selecting-text-in-an-element-akin-to-highlighting-with-your-mouse