## GitHub Pages Enhancements

[Download the zip here.](https://github.com/GaryRidgway/ghpEnhancements/raw/main/build.zip)